def toplamhacim(r1,h1,r2,h2):
  pi = 3.14
  
  
  konihacmi=(pi*(r1**2)*h1)/3
  
def v_silindir(r,h):
  pi = 3.14
  v2 = pi*(r**2)*h
  return v2
  
def toplamHacim():
  toplam = v1+v2
  return toplam