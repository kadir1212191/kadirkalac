import geo
miktar = int(input("Kac tane minare? : "))
r1=int(input("Koni yaricapi? : "))
h1=int(input("Koni yüksekliği? : "))

r2=int(input("Silindir Yarıcapi? : "))
h2=int(input("Silindir Yüksekliği? : "))


result = geo.Toplamhacim(r1,h1,r2,h2)
print(result)