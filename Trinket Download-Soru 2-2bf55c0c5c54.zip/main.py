ad = input("Adınızı girin: ")
soyad = input("Soyadınızı girin: ")

sonuc = ad[0] + "." + soyad[0]
print("Çıktı:", sonuc)