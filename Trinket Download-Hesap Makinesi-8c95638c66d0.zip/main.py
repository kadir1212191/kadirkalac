def toplama(a,b):
  print(a+b)
  
def cikarma(a,b):
  print(a-b)
  
def carpma(a,b):
  print(a*b)
  
def bolme(a,b):
  print(a/b)
  
a=int(input("Zahl1="))
b=int(input("Zahl2="))
operator=input("Operation:")
if operator=="+":
   toplama(a,b)
elif operator=="-":
  cikarma(a,b)
elif operator=="*":
  carpma(a,b)
elif operator=="/":
  bolme(a,b)
else:
  print("Fehler")
  