kelime = input("Bir sözcük girin: ")

sonuc = kelime[0] + kelime[-1]
print(sonuc)